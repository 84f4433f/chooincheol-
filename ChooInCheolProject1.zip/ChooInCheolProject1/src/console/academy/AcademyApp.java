package console.academy;

import java.util.Scanner;

import thread23.MediaPlayer;


public class AcademyApp {

	public static void main(String[] args) {
		//배열 사용]
		//AcademyLogic logic = new AcademyLogic();
		//컬렉션 사용]
		 MediaPlayer musicPlayer = new MediaPlayer("src/music/비비 (BIBI)-01-밤양갱.mp3");
	     musicPlayer.setDaemon(true); // 메인 스레드 종료 시 함께 종료
	     musicPlayer.start(); // 프로그램 시작 시 음악 재생
		AcademyCollectionLogic logic = new AcademyCollectionLogic();
		logic.loadPerson();
		
		Scanner sc = new Scanner(System.in);
		
		while(true) {
			//1.메인 메뉴 출력
			logic.printMainMenu();
			//2.메인메뉴 번호 입력받기
			int mainMenu=logic.getMenuNumber();
			 // 3. 메인 메뉴에 따른 분기
            if (mainMenu == 9) { // 종료
                if (musicPlayer != null) {
                    musicPlayer.stop_(); // 프로그램 종료 시 음악 중지
                }
                System.out.println("프로그램을 종료합니다.");
                break; // while 루프 종료
            }

            logic.seperateMainMenu(mainMenu); // 메인 메뉴 분기
        }

        sc.close(); // Scanner 닫기
	}/////main

}////////class
