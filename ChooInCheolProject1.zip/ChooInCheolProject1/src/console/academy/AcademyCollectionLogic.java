package console.academy;

import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.Scanner;
import java.util.Vector;


import common.utils.CommonUtils;

public class AcademyCollectionLogic {
	//[멤버 상수]
	public static final int MAX_PERSON =3;
	//[멤버변수]
	List<Person> person;
	private boolean removed;
	//[생성자]
	public AcademyCollectionLogic() {
		person = new Vector<>();
		
	}////////
	//[멤버 메소드]
	/*
	 * 1]메뉴 출력용 메소드
	 * 매개변수:NO
	 * 반환타입:void
	 */
	public void printMainMenu() {
		System.out.println("====================메인 메뉴====================");
		System.out.println(" 1.입력 2.출력 3.수정 4.삭제 5.검색   9.종료");
		System.out.println("===============================================");
		System.out.println("메인를 입력하세요?");
	}//////////////printMainMenu()
	/*
	 * 2]메뉴 번호 입력용 메소드
	 * 매개변수:NO
	 * 반환타입:int
	 */
	public int getMenuNumber() {
		
		Scanner sc = new Scanner(System.in);
		int menu = -1;
		while(true) {
			try {
				String menuStr=sc.nextLine().trim();
				menu=Integer.parseInt(menuStr);
				break;
			}
			catch(Exception e) {
				System.out.println("메뉴 번호만..");				
			}
			
		}////while		
		return menu;
	}/////////////////getMenuNumber()
	/*
	 * 3]메뉴 번호에 따른 분기용 메소드
	 * 매개변수:int(메인메뉴)
	 * 반환타입:void
	 */
	public void seperateMainMenu(int mainMenu) {
		switch(mainMenu) {
			case 1://입력
				setPerson();
				break;
			case 2://출력
				printPerson();
				break;
			case 3://수정
				updatePerson();
				break;
			case 4://삭제
				deletePerson();
				break;
			case 5://검색
				 searchPerson();
				break;
		
			
			case 9://종료
				
				System.out.println("프로그램을 종료합니다");
				savePerson();
				System.exit(0);
			default:System.out.println("메뉴에 없는 번호입니다");
		}///switch
		
	}////////////////////seperateMainMenu(int mainMenu)	
	
	
	/*
	 * 4]서브메뉴 출력용 메소드
	 * 매개변수:NO
	 * 반환타입:void
	 */
	
	/*
	 * 5]서브메뉴에 따른 학생 및 교사 데이타 입력용 메소드
	 * 매개변수:int(서브메뉴)
	 * 반환타입:void
	 */
	private void setPerson( ) {
		//정원이 찼는지 여부 판단]
		if(person.size()==MAX_PERSON) {
			System.out.println("We're at capacity. You can't enter any more.");
			return;
		}
		//정원이 안 찬 경우 즉 index가 -1이 아닌 경우...
		Scanner sc = new Scanner(System.in);
		String name = null;
		while (true) {
            try {
                System.out.println(">>> 이름을 입력하세요?");
                name = sc.nextLine().trim(); 

                if (name.matches(".*\\d.*")) { 
                    throw new IllegalArgumentException();  
                }//if

                break;  
            } //try
            catch (IllegalArgumentException e) {  
                System.out.println("이름에 숫자는 안됩니다. 다시 입력하세요.");  
            }
        }//while
		
		
		System.out.println(">>>나이를 입력하세요?");
		int age= -1;
		while(true) {
			try {
				age = Integer.parseInt(sc.nextLine().trim());
				break;
			}
			catch(NumberFormatException e) {
				System.out.println("나이는 숫자만...");
			}
			
		
		}/////while
		
		
		String address = null;
		 while (true) {
	            try {
	                System.out.println(">>> 사는 곳을 입력하세요?");
	                address = sc.nextLine().trim(); 

	                if (address.matches(".*\\d.*")) { 
	                    throw new IllegalArgumentException();  
	                }//if

	                break;  
	            } //try
	            catch (IllegalArgumentException e) {  
	                System.out.println("주소에 숫자는 안됩니다. 다시 입력하세요.");  
	            }
	        }//while

		
		System.out.println(">>>연락처를 입력하세요?(예:01012345678)");
		String phoneNumber = null;
		while (true) {
	        phoneNumber = sc.nextLine().trim();
	        if (phoneNumber.matches("^\\d+$")) { 
	            break;
	        } else {
	            System.out.println("핸드폰 번호는 숫자만 입력하세요.");
	        }
	    }
		
		
	 
	Person newPerson = new Person(name, age, address, phoneNumber);
      person.add(newPerson);
      savePerson();
	
    
	}
	 
	
	
	/*
	 * 6]출력용 메소드
	 * 매개변수:NO
	 * 반환타입:void
	 */
	private char getChosung(char c) {
	    final int BASE_CODE = 0xAC00; // '가'의 유니코드 값
	    final int CHOSUNG_STEP = 588; // 초성 한글 자음 개수
	    int chosungIndex = (c - BASE_CODE) / CHOSUNG_STEP;
	    // 초성 값에 해당하는 유니코드를 더하고 해당 문자를 반환
	    return (char) (0x1100 + chosungIndex);
	}//getChosung(char c)
	private void printPerson() {
	  
	    char currentChosung = '썕'; // 현재 초성을 기억하기 위한 변수

	    for (Person p : person) {
	        char firstChosung = getChosung(p.name.charAt(0)); // 이름의 첫 글자의 초성 추출
	        if (firstChosung != currentChosung) { // 초성이 바뀌면 구분 출력
	            System.out.println("[" + firstChosung + "으로 시작하는 명단]");
	            currentChosung = firstChosung; // 현재 초성 업데이트
	        }// if 
	        p.print(); // 개별 사람 정보 출력
	    }//  for
	}//printPerson() 
	

	
	
	//7]검색용 메소드
	private void searchPerson() {
		Person findPerson=findPersonByName("검색");
		if(findPerson !=null) {
			System.out.println(String.format("[%s로 검색한 결과]", findPerson.name));
			findPerson.print();
		}
	}
	//7-1)수정/삭제/검색메뉴의 공통으로 사용하는 이름으로 찾는 메소드	/*
	 
	 //매개변수:String(수정/삭제/검색용 타이틀)
	 //반환타입:Person타입
	 
	private Person findPersonByName(String message) {
		
		System.out.println(message+"할 사람의 이름을 입력하세요?");
		Scanner sc = new Scanner(System.in);
		String name = sc.nextLine().trim();
		
		for(Person p:person)
			if(p.name.equals(name))
				return p;
		System.out.println(name+"로(으로) 검색된 정보가 없어요");
		return null;	
	}///////////searchPerson()
	//9]수정용 메소드
	private void updatePerson() {
		Person findPerson=findPersonByName("수정");
		if(findPerson !=null) {
			Scanner sc = new Scanner(System.in);
			//나이 수정
			System.out.printf("(현재 나이 %s)몇 살로 수정하시겠습니까?%n",findPerson.age);
			while(true) {
				try {
					findPerson.age=Integer.parseInt(sc.nextLine().trim());
					break;
				}
				catch(Exception e) {
					System.out.println("나이는 숫자만 입력하세요");
				}
			}///while
			System.out.printf("(현재 주소 %s)어디로 수정하시겠습니까?%n",findPerson.address);
			while(true) {
				try {
					findPerson.address=sc.nextLine().trim();
					break;
				}
				catch(Exception e) {
					System.out.println("주소는 숫자를 입력하지 마세요");
				}
			}///while
			
			System.out.printf("(현재 핸드폰번호 %s)어떤 번호로 수정하시겠습니까?%n",findPerson.phoneNumber);
			String newPhoneNumber = null;
	        while (true) {
	            newPhoneNumber = sc.nextLine().trim();
	            if (newPhoneNumber.matches("^\\d+$")) { // 숫자만 허용
	                findPerson.phoneNumber = newPhoneNumber;
	                break;
	            } else {
	                System.out.println("핸드폰 번호는 숫자만 입력하세요.");
	            }
	        }
			System.out.printf("[%s가(이) 아래와 같이 수정되었습니다]%n",findPerson.name);
			findPerson.print();//수정 내용을 확인하기 위한 출력
			savePerson();
		
		}
		
	}//////////updatePerson()
	//10]삭제용
	//문]삭제처리 하시오(힌트:찾은 Person형 배열 요소를 null로 설정) 
	private void deletePerson() {
		Person findPerson=findPersonByName("삭제");
		if(findPerson !=null) {
			boolean removed = false; // 삭제 여부를 확인
			for(Person p:person)
				if(findPerson.equals(p)) {
					person.remove(p);
					removed = true;
					System.out.printf("[%s가(이) 삭제 되었습니다]%n",findPerson.name);
					savePerson();
					break;
					
				}//if
			
		}//if
		if (removed) {
            savePerson(); // 변경 사항을 파일에 저장
        }
		
	}//////////deletePerson()
	//이게 6번세이브 데이터
	private void savePerson() {
		//컬렉션에 객체가 저장되었는지 판단
		if(person.isEmpty()) {
			System.out.println("파일로 저장할 명단이 없어요");
			return;
		}
		//컬렉션에 저장된 객체가 있는 경우
		ObjectOutputStream out=null;
		try {
			out = new ObjectOutputStream(new FileOutputStream("src/console/academy/Persons.dat"));
			//컬렉션에 저장된 데이타를 파일(out)로 출력
			out.writeObject(person);//person는 List<Person>타입
			System.out.println("파일이 저장되었습니다");
		}
		catch(IOException e) {
			System.out.println("파일 저장시 오류:"+e.getMessage());
		}
		finally {
			try {
				if(out !=null) out.close();
			}
			catch(Exception e) {}
		}
		
	}/////////////savePerson()
	void loadPerson() {
		ObjectInputStream ois= null;
		try {
			ois = new ObjectInputStream(new FileInputStream("src/console/academy/Persons.dat"));
			//ois로 읽어서 컬렉션 person에 저장
			person=(List<Person>)ois.readObject();			
		}
		catch(Exception e) {}
		finally {
			try {
				if(ois != null) ois.close();
			}
			catch(IOException e) {}
		}
		
	}////////loadPerson()
}/////class
