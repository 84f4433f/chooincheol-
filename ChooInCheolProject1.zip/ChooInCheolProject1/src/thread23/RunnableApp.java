package thread23;


class Soldier{
	void longMethod() {
		for(int i=1;i<=10;i++) {
			System.out.println(String.format("스레드명:%s,i=%d",Thread.currentThread().getName(),i));
			try {
				Thread.sleep(1000);
			} 
			catch (InterruptedException e) {e.printStackTrace();}
		}
	}///longMethod()
}////////Soldier
//상속받은 longMethod() 스레드로 구현하자
//1]Runnable인터페이스 상속
class Commander extends Soldier implements Runnable{
	//2]run()오버라이딩
	@Override
	public void run() {
		longMethod();		
	}
	
}/////////////////Commander

public class RunnableApp {

	public static void main(String[] args) {
		Commander commander = new Commander();
		//commander.start();//[x]undefined
		System.out.println(commander instanceof Commander);
		System.out.println(commander instanceof Runnable);
		//System.out.println(commander instanceof Thread);//[x]
		//Runnable타입을 Thread타입으로 변환.(상속관계가 없어서 형변환 불가)
		Thread th1 = new Thread(commander);
		th1.start();
		Thread th2 = new Thread(commander, "두번째 스레드");
		th2.start();
		
	}///main

}///class
