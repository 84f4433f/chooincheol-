package thread23;

import java.io.FileInputStream;

import javazoom.jl.player.Player;

import javazoom.jl.player.Player;


public class MediaPlayer extends Thread {
	
	private Player player;
	private FileInputStream fis;
	String filePath;
	
	public MediaPlayer(String filePath) {		
		this.filePath = filePath;
	}//////
	//재생
	void play() {
		try {
			fis = new FileInputStream(filePath);
			player = new Player(fis);
			player.play();
		}
		catch(Exception e) {e.printStackTrace();}
	}/////
	//중지
	public void stop_() {
		if(player !=null) {
			player.close();
			player=null;
		}
	}
	@Override
	public void run() {
		play();//음악 재생
	}
}
