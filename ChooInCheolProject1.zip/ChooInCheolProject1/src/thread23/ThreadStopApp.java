package thread23;

class ThreadStop extends Thread{
	
	//boolean isFlag;//플래그 변수 이용시-비 추천]
	
	@Override
	public void run() {
		
		/*
		//플래그 변수 사용시(비추천)-스레드가 멈추지 않을 수 있다
		//왜냐하면 isFlag를 true로 설정한다 하더라도
		//while문 안의 모든 명령문의 실행이 끝나야 다시 반복조건을 검사하니까
		int i=1;
		while(!isFlag) {
			System.out.println("i="+i++);
			try {
				sleep(1000);
			} 
			catch (InterruptedException e) {e.printStackTrace();}
		}*/
		//[interrupt()메소드 호출(추천)-InterruptedException예외 발생시키기위해서]
		//스레드 작업중간에 멈출 수 있다
		//InterruptedException이 발생하면 무조건 catch절로 들어가니까
		
		int i=1;
		try {
			while(true) {
				System.out.println("i="+i++);			
				sleep(1000);
				
			}
		}
		catch(InterruptedException e) {
			System.out.println("interrupt()호출");
		}
		finally {
			System.out.println("스레드 DEAD상태");
		}
		
	}///
}/////////////
public class ThreadStopApp {

	public static void main(String[] args) {
		ThreadStop thread = new ThreadStop();
		thread.start();
		
		//main 스레드를 5초동안 Wait상태 전이
		try {
			Thread.sleep(5000);
		} 
		catch (InterruptedException e) {e.printStackTrace();}
		//플래그 이용] boolean형 플래그 변수 사용-비추천		
		//메인 스레드가 5초후 Running상태에서 이 코드 실행
		//thread.isFlag=true;//실제로는 특정 조건일때 true설정
		
		//InterruptedException예외 발생
		if(thread.isAlive()) thread.interrupt();
		
	}/////main
}////class
